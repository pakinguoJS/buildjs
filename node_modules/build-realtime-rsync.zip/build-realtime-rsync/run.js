var FS = require('fs');
var inotify = require('build-realtime-rsync');

var src = "";
var dst = "";

inotify.exec(src, dst);